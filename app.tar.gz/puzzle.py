import flet as ft
import flet_fastapi

async def main(page: ft.Page):
    page.title = "Puzzle"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 50
    page.spacing = 0
    await page.update_async()

    images_per_row = 3

    movimiento = 0
    contador_movimientos = ft.Text(value=f"Movimientos: {movimiento}", size=22)

    await page.add_async(ft.Row([contador_movimientos], alignment=ft.MainAxisAlignment.CENTER))

    async def drag_accept(e):
        if e.control.content.src.split("/a")[1][:2] == '10':
            origen = e.page.get_control(e.src_id).content.content
            destino = e.control.content

            aux = origen.src
            origen.src = destino.src
            destino.src = aux

            nonlocal movimiento
            movimiento += 1
            contador_movimientos.value = f"Movimientos: {movimiento}"
            ok = False
            for control in page.controls:
                if hasattr(control, 'content') and hasattr(control.content, 'controls'):
                    for subcontrol in control.content.controls:
                        image_index = int(subcontrol.content.content.src.split("/a")[1].split(".")[0])

                        aux = 0
                        # Aplicar condiciones según el índice obtenido
                        if 3 < image_index < 7:
                            aux = 2
                        elif image_index > 6:
                            aux = 4

                        # Calcular la diferencia y mostrar información
                        difference = int(subcontrol.uid[1:]) - (5 + aux + images_per_row * image_index)
                        if image_index != 10:
                            if difference != 0:
                                ok = False
                                break
                            else:
                                ok = True
                                print(f'Img: {image_index}     ID: {subcontrol.uid[1:]}    Dif.: {difference}')
            if ok:
                print('Resolviste')

            await page.update_async()
        else:
            print('Movimiento incorrecto')

    async def create_items(count):
        items = []
        img_id = [3, 1, 7, 2, 4, 8, 5, 6, 10]
        for i in img_id:
            image = ft.Image(
                src=f"assets/img/a{i}.png",  # Ajusta la ruta según la ubicación real de tus imágenes
                fit=ft.ImageFit.NONE,
                repeat=ft.ImageRepeat.NO_REPEAT,
                border_radius=ft.border_radius.all(0),
            )
            draggable = ft.Draggable(
                group="items",
                content=ft.DragTarget(
                    group="items",
                    content=image,
                    on_accept=drag_accept,
                ),
                data=image,
            )
            items.append(draggable)
        return items

    items = await create_items(images_per_row * images_per_row) 

    current_row = ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=0)
    for item in items:
        print(item.content.content.src)
        current_row.controls.append(item)
        if len(current_row.controls) == images_per_row:
            container = ft.Container(content=current_row)
            await page.add_async(container)
            current_row = ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=0)

    if current_row.controls:
        container = ft.Container(content=current_row)  
        await page.add_async(container) 

    await page.update_async()

app = flet_fastapi.app(main)

app.mount("/assets", flet_fastapi.FletStaticFiles(assets_dir="C:/Proyectos/Python/Flet/Proyecto/assets"))
