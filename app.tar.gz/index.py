# index.py
import flet as ft
import flet_fastapi
from tictactoe import main as tictactoe_main
from wordle import main as wordle_main
from shake import main as shake_main
from puzzle import main as puzzle_main

async def root_main(page: ft.Page):
    await page.add_async(ft.Text("This is root app!"))
    await page.add_async(ft.Image(src=f"assets/img/a5.png"))

async def tictac(page: ft.Page):
    await tictactoe_main(page)

async def word(page: ft.Page):
    await wordle_main(page)

async def shake(page: ft.Page):
    await shake_main(page)
    
async def puzzle(page: ft.Page):
    await puzzle_main(page)

app = flet_fastapi.FastAPI()

app.mount("/assets", flet_fastapi.FletStaticFiles(assets_dir="C:/Proyectos/Python/Flet/Proyecto/assets"))
app.mount("/tic", flet_fastapi.app(tictac))
app.mount("/shk", flet_fastapi.app(shake))
app.mount("/word", flet_fastapi.app(word))
app.mount("/", flet_fastapi.app(puzzle_main))
app.mount("/puz", flet_fastapi.app(root_main))
