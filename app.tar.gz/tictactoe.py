import flet as ft
import flet_fastapi
import pymysql
import asyncio

conexion = pymysql.connect(
                host='localhost',
                user='root',
                password='1212',
                database='prueba',
                cursorclass=pymysql.cursors.DictCursor
            )

jugador = 0
fin_partida = 0
turno = 0
all_buttons = []
shutdown_event = asyncio.Event()
shutdown_event.clear()

async def refrescar(page: ft.Page, all_buttons):
        for button in all_buttons:
            try:
                # Crear un cursor para ejecutar consultas SQL
                with conexion.cursor() as cursor:
                    # Ejecutar la consulta SELECT
                    cursor.execute(f"SELECT jugador FROM tictactoe WHERE posicion = '{button.key}'")

                    # Obtener todas las filas de resultados
                    resultado = cursor.fetchone()

                    if resultado["jugador"] == "1":
                        texto = ft.Text("X", size=30, weight=500)
                        button.content = texto
                        
                    if resultado["jugador"] == "2":
                        texto = ft.Text("O", size=30, weight=500)
                        button.content = texto

            except Exception as e:
                print(f"Ocurrió un error: {e}")

            finally:
                # Cerrar la conexión
                if 'conexion' in locals() and conexion.open:
                    conexion.close()
            await page.update_async()

async def comprobar(page: ft.Page):
    try:
        global fin_partida
        with conexion.cursor() as cursor:
            cursor.execute(f"SELECT * FROM tictactoe")
            resultados = cursor.fetchall()

            winning_combinations = [
                [0, 1, 2],
                [3, 4, 5],
                [6, 7, 8],
                [0, 3, 6],
                [1, 4, 7],
                [2, 5, 8],
                [0, 4, 8],
                [2, 4, 6],
            ]
            cursor.execute(f"SELECT jugador FROM jugadores WHERE identificacion = '{page.session_id}'")
            jugador = cursor.fetchone()
            for combination in winning_combinations:
                players_in_combination = [resultados[pos]["jugador"] for pos in combination]

                if all(player == "1" for player in players_in_combination):
                    print("Victoria de Jugador 1")
                    if jugador["jugador"] == "1":
                        alerta = ft.AlertDialog(title=ft.Text("Ganaste"), on_dismiss=lambda e: print("Alerta cerrada"))
                        page.dialog = alerta
                        alerta.open = True
                        fin_partida = 1
                        await page.update_async() 
                    else:
                        alerta = ft.AlertDialog(title=ft.Text("Perdiste"), on_dismiss=lambda e: print("Alerta cerrada"))
                        page.dialog = alerta
                        alerta.open = True
                        fin_partida = 1
                        await page.update_async()
                    return
                elif all(player == "2" for player in players_in_combination):
                    print("Victoria de Jugador 2")
                    if jugador["jugador"] == "2":
                        print("2 gana")
                        alerta = ft.AlertDialog(title=ft.Text("Ganaste"), on_dismiss=lambda e: print("Alerta cerrada"))
                        page.dialog = alerta
                        alerta.open = True
                        fin_partida = 1
                        await page.update_async()  # Esperar la actualización antes de salir
                    else:
                        print("2 pierde")
                        alerta = ft.AlertDialog(title=ft.Text("Perdiste"), on_dismiss=lambda e: print("Alerta cerrada"))
                        page.dialog = alerta
                        alerta.open = True
                        fin_partida = 1
                        await page.update_async()  # Esperar la actualización antes de salir
                    return

            cursor.execute(f"SELECT count(posicion) as restantes FROM tictactoe WHERE jugador = ''")
            restantes = cursor.fetchone()
            if restantes["restantes"] == 0 and fin_partida == 0:
                alerta = ft.AlertDialog(title=ft.Text("Empate"), on_dismiss=lambda e: print("Alerta cerrada"))
                page.dialog = alerta
                alerta.open = True
                await asyncio.sleep(2)
                fin_partida = 1
                await page.update_async()  # Esperar la actualización antes de salir

    except Exception as e:
        print(f"Ocurrió un error: {e}")

    finally:
        # Cerrar la conexión
        if 'conexion' in locals() and conexion.open:
            conexion.close()

async def obtener_posicion(page: ft.Page, boton, alerta):
    global all_buttons
    global fin_partida
    if fin_partida == 0:
        try:
            with conexion.cursor() as cursor:
                cursor.execute(f"SELECT jugador, turno FROM jugadores WHERE identificacion = '{page.session_id}'")
                jugador = cursor.fetchone()

                if jugador["jugador"] == "1" or jugador["jugador"] == "2":
                    if jugador["jugador"] == str(jugador["turno"]):
                        global turno
                        turno = jugador["turno"]
                        cursor.execute(f"SELECT jugador FROM tictactoe WHERE posicion = '{boton.control.key}'")
                        posicion = cursor.fetchone()
                        if posicion["jugador"] == '':
                            print(boton.control.key)
                            cursor.execute(f"UPDATE tictactoe SET jugador = {jugador['jugador']} WHERE posicion = '{boton.control.key}'")
                            conexion.commit()
                            if jugador["jugador"] == "1":
                                texto = ft.Text("X", size=30, weight=500)
                                boton.control.content = texto
                                cursor.execute(f"UPDATE jugadores SET turno = 2")
                                conexion.commit()
                                await refrescar(page, all_buttons)
                                await page.update_async()
                                await comprobar(page)
                                
                            if jugador["jugador"] == "2":
                                texto = ft.Text("O", size=30, weight=500)
                                boton.control.content = texto
                                cursor.execute(f"UPDATE jugadores SET turno = 1")
                                conexion.commit()
                                await refrescar(page, all_buttons)
                                await page.update_async()
                                await comprobar(page)
                            await comprobar(page)
                        else:
                            alerta.open = True
                            await page.update_async()
                await comprobar(page)

        except Exception as e:
            print(f"Ocurrió un error: {e}")

        finally:
            # Cerrar la conexión
            if 'conexion' in locals() and conexion.open:
                conexion.close()

async def main(page: ft.Page):
    global fin_partida
    shutdown_event.clear()
    page.title = "Tic Tac Toe"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    alerta = ft.AlertDialog(title=ft.Text("Posicion ocupada"), on_dismiss=lambda e: print("Alerta cerrada"))
    page.dialog = alerta
    async def on_close(e):
        with conexion.cursor() as cursor:
            cursor.execute(f"SELECT * FROM jugadores WHERE identificacion = '{page.session_id}'")
            jugador_actual = cursor.fetchone()

            if jugador_actual:
                cursor.execute(f"UPDATE jugadores SET identificacion = '' WHERE jugador = {jugador_actual['jugador']}")
                conexion.commit()

        shutdown_event.set()

    page.on_disconnect = on_close
    global jugador
    with conexion.cursor() as cursor:
        cursor.execute(f"SELECT * FROM jugadores")
        resultados = cursor.fetchall()
        if resultados[0]["identificacion"] == page.session_id or resultados[1]["identificacion"] == page.session_id:
            pass
        else:
            if resultados[0]["identificacion"] == '':
                cursor.execute(f"UPDATE jugadores SET identificacion = '{page.session_id}' WHERE jugador = 1")
                print(f"IP registrada: {page.session_id}")
                conexion.commit()
                jugador = 1
            elif resultados[1]["identificacion"] == '':
                cursor.execute(f"UPDATE jugadores SET identificacion = '{page.session_id}' WHERE jugador = 2")
                conexion.commit()
                jugador = 2
    
    async def obtener_posicion_click(e):
        await obtener_posicion(page, e, alerta)

    boton_a1 = ft.Container(
                    key="a1",
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.GREY_100,
                    width=80,
                    height=80,
                    border_radius=10,
                    on_click=obtener_posicion_click,
                )
    boton_a2 = ft.Container(
                    key="a2",
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.GREY_100,
                    width=80,
                    height=80,
                    border_radius=10,
                    on_click=obtener_posicion_click,
                )
    boton_a3 = ft.Container(
                    key="a3",
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.GREY_100,
                    width=80,
                    height=80,
                    border_radius=10,
                    on_click=obtener_posicion_click,
                )

    boton_b1 = ft.Container(
                    key="b1",
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.GREY_100,
                    width=80,
                    height=80,
                    border_radius=10,
                    on_click=obtener_posicion_click,
                )
    boton_b2 = ft.Container(
                    key="b2",
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.GREY_100,
                    width=80,
                    height=80,
                    border_radius=10,
                    on_click=obtener_posicion_click,
                )
    boton_b3 = ft.Container(
                    key="b3",
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.GREY_100,
                    width=80,
                    height=80,
                    border_radius=10,
                    on_click=obtener_posicion_click,
                )

    boton_c1 = ft.Container(
                    key="c1",
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.GREY_100,
                    width=80,
                    height=80,
                    border_radius=10,
                    on_click=obtener_posicion_click,
                )
    boton_c2 = ft.Container(
                    key="c2",
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.GREY_100,
                    width=80,
                    height=80,
                    border_radius=10,
                    on_click=obtener_posicion_click,
                )
    boton_c3 = ft.Container(
                    key="c3",
                    alignment=ft.alignment.center,
                    bgcolor=ft.colors.GREY_100,
                    width=80,
                    height=80,
                    border_radius=10,
                    on_click=obtener_posicion_click,
                )

    row1 = ft.Row([boton_a1, boton_a2, boton_a3], alignment=ft.MainAxisAlignment.CENTER)
    row2 = ft.Row([boton_b1, boton_b2, boton_b3], alignment=ft.MainAxisAlignment.CENTER)
    row3 = ft.Row([boton_c1, boton_c2, boton_c3], alignment=ft.MainAxisAlignment.CENTER)

    await page.add_async(row1)
    await page.add_async(row2)
    await page.add_async(row3)    
     
    global all_buttons
    all_buttons.extend([boton_a1, boton_a2, boton_a3, boton_b1, boton_b2, boton_b3, boton_c1, boton_c2, boton_c3])

    await refrescar(page, all_buttons)

    _loop = asyncio.get_event_loop()
    
    async def periodic_task():
        global fin_partida
        fin_partida = 0
        while not shutdown_event.is_set() and fin_partida == 0:
            try:
                await refrescar(page, all_buttons)
                await comprobar(page)
                await page.update_async()
                await asyncio.sleep(0.5)
            except Exception as e:
                print(f"Error en periodic_task: {e}")

        with conexion.cursor() as cursor:
            cursor.execute(f"UPDATE jugadores SET turno = 1, identificacion = ''")
            conexion.commit()
            cursor.execute(f"UPDATE tictactoe SET jugador = ''")
            conexion.commit()
        fin_partida = 1
        await page.update_async()
        print("Fin loop")
    _loop.create_task(periodic_task())

app = flet_fastapi.app(main)
    