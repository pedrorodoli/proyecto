import flet as ft
import random
import asyncio
import flet_fastapi

lista_palabras = ["perros",]

current_row = -1
correcto = False

palabra = random.choice(lista_palabras)

async def main(page: ft.Page):
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    global palabra

    # Lista para almacenar las filas de contenedores de letras
    filas_letras = []

    for _ in range(6):
        # Lista para almacenar los contenedores de letras en cada fila
        contenedores_letras = []

        # Crear contenedores para cada letra y agregarlos a la lista
        for letra in palabra:
            contenedor = ft.Container(
                width=50,
                height=50,
                border_radius=10,
                bgcolor=ft.colors.GREY_300,
                content=ft.Text('', size=20, color=ft.colors.WHITE),
                alignment=ft.alignment.center,
                animate=ft.animation.Animation(500, ft.AnimationCurve.EASE_IN_OUT),
            )
            contenedores_letras.append(contenedor)

        # Crear una fila con los contenedores de letras y alinear al centro
        fila_letras = ft.Row(contenedores_letras, alignment=ft.MainAxisAlignment.CENTER, spacing=4)
        filas_letras.append(fila_letras)

    text_field = ft.TextField(
        label="Escribe aquí...",
        width=150,
        height=65,
        border_radius=5,
        border=ft.border.all(1, ft.colors.GREY),
        autofocus=True,
        max_length=len(palabra)
    )

    global button
    button = ft.ElevatedButton(
        text="Enviar",
        width=100,
        height=45,
        style=ft.ButtonStyle(bgcolor={ft.MaterialState.DEFAULT: ft.colors.GREEN_400}, color={ft.MaterialState.DEFAULT: ft.colors.WHITE}),
        on_click=lambda e: asyncio.create_task(change_row_and_check(page, text_field, filas_letras)),
    )

    fila_text_field = ft.Row([text_field, button], alignment=ft.MainAxisAlignment.CENTER, spacing=8)

    # Crear una columna con las filas de contenedores y el TextField
    columna_principal = ft.Column(filas_letras + [fila_text_field])

    # Añadir la columna al page
    await page.add_async(columna_principal)

# Función para cambiar a la siguiente fila y comprobar la palabra ingresada
async def change_row_and_check(page, text_field, filas_letras):
    global current_row
    global correcto
    if current_row > (len(filas_letras) + 1)*-1:
        await check_word(page, text_field, filas_letras[current_row].controls, button)
        if not (current_row > (len(filas_letras) + 1)*-1) and not correcto:
            await page.add_async(ft.Container(
                            content=ft.Text(f'Inténtalo de nuevo', size=20, color=ft.colors.BLACK, weight=ft.FontWeight.W_700,),
                            alignment=ft.alignment.center,
                            )
                        )
            button.disabled = True
            await page.update_async()
        await page.update_async()

# Función para comprobar la palabra ingresada
async def check_word(page, text_field, contenedores_letras, boton):
    palabra_ingresada = text_field.value.upper()
    text_field.value = ''
    global current_row
    global correcto
    
    if len(palabra_ingresada) == len(contenedores_letras):
        for i, letra in enumerate(palabra_ingresada):
            if letra == palabra[i].upper():
                contenedores_letras[i].width = 70 
                contenedores_letras[i].height = 70 
                contenedores_letras[i].bgcolor = ft.colors.GREEN_400
                contenedores_letras[i].content = ft.Text(f'{letra}', size=20, color=ft.colors.WHITE, weight=ft.FontWeight.W_700,)
                await contenedores_letras[i].update_async()
                await asyncio.sleep(0.5)
                contenedores_letras[i].width = 50 
                contenedores_letras[i].height = 50 
                await contenedores_letras[i].update_async()

            elif letra in palabra.upper():
                contenedores_letras[i].bgcolor = ft.colors.YELLOW_400
                contenedores_letras[i].content = ft.Text(f'{letra}', size=20, color=ft.colors.WHITE, weight=ft.FontWeight.W_700,)
                contenedores_letras[i].width = 70 
                contenedores_letras[i].height = 70 
                await contenedores_letras[i].update_async()
                await asyncio.sleep(0.5)
                contenedores_letras[i].width = 50 
                contenedores_letras[i].height = 50 
                await contenedores_letras[i].update_async()
            else:
                contenedores_letras[i].bgcolor = ft.colors.GREY_600
                contenedores_letras[i].content = ft.Text(f'{letra}', size=20, color=ft.colors.WHITE, weight=ft.FontWeight.W_300,)
                contenedores_letras[i].width = 70 
                contenedores_letras[i].height = 70 
                await contenedores_letras[i].update_async()
                await asyncio.sleep(0.5)
                contenedores_letras[i].width = 50 
                contenedores_letras[i].height = 50 
                await contenedores_letras[i].update_async()
            await asyncio.sleep(0.5)

        palabra_formada = ''.join([contenedor.content.value for contenedor in contenedores_letras])
        # Comprobar si la palabra formada coincide con la palabra objetivo
        if palabra_formada.upper() == palabra.upper():
            correcto = True
            await page.add_async(ft.Container(
                            content=ft.Text(f'CORRECTO', size=20, color=ft.colors.BLACK, weight=ft.FontWeight.W_700,),
                            alignment=ft.alignment.center,
                            )
                        )
            boton.disabled = True
            await page.update_async()
        current_row -= 1
        await page.update_async()
    else:
        alerta = ft.AlertDialog(title=ft.Text(f"La palabra debe tener {len(palabra)} letras"), on_dismiss=lambda e: print("Alerta cerrada"))
        page.dialog = alerta
        alerta.open = True
        await page.update_async()

app = flet_fastapi.app(main)
